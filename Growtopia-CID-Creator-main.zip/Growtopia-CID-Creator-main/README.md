### How to use CID-Creator?

* Visit https://console.cloud.google.com/ and click the emoji that in the middle of gift and question mark emoji on right corner.
* After your cloud shell terminal ready paste this > git clone https://github.com/CapciGithub/Growtopia-CID-Creator and press enter.
* Write cd Growtopia-CID-Creator/ and press enter again.
* Now click the Open editor button on the right corner and wait for editor to load.
* After editor loaded click the Growtopia-CID-Creator folder then click corefunc.h and edit Growid_acc = "sakgay31"; Password_acc = "loler1234@"; to whatever you want to create.
* When your editing is done do CTRL + S or click File on the left corner and click Save
* Now, click open terminal and wait for terminal to open.
* After terminal loaded enter those commands: chmod +x build.sh and hit enter then ./build* and wait for it to load. ( Note: It will ask you this: Do you want to continue? [Y/n] write y into terminal and hit enter button )
* If you can see this message on your terminal: Tool succesfuly builded, you can start creating ID by typing ./createid then type ./createid but, If you can't see that message write ./build* again.
* If you want to stop creating do CTRL+C and to download created accounts write this: cloudshell download acc.txt and click the download button.
* Note: It just creates CID, doesn't skips the tutorial so they will be bot accounts. You can enter them If you want but, If you do you gotta finish the tutorial but If you use they as bots you can do what normal player does.
* Note 2: If it stucks at connected to server/disconnected server after you created accounts probably you're got ip limited you gotta do this: https://media.discordapp.net/attachments/900416037781131305/901503881534664815/Ekran_Alnts.PNG?width=357&height=494


### How to use CID-Creator? ( Tutorial with Video )

* https://streamable.com/k6nhvk
* Note: It just creates CID, doesn't skips the tutorial so they will be bot accounts. You can enter them If you want but, If you do you gotta finish the tutorial but If you use they as bots you can do what normal player does.
* Note 2: If it stucks at connected to server/disconnected server after you created accounts probably you're got ip limited you gotta do this: https://media.discordapp.net/attachments/900416037781131305/901503881534664815/Ekran_Alnts.PNG?width=357&height=494
